﻿using System;
using System.Threading.Tasks;
using Nop.Services.Logging;
using Nop.Core.Events;
using Nop.Data;
using Nop.Plugin.Misc.CheckOrderStatus.Domain;
using Nop.Core;
using System.Linq;
using Nop.Core.Domain.Topics;
using Nop.Web.Areas.Admin.Models.Topics;
using Nop.Services.Stores;

namespace Nop.Plugin.Misc.CheckOrderStatus.Services
{
    public class CheckOrderStatusService
    {
        private readonly IRepository<CheckOrderStatusLog> _checkOrderStatusRepository;
        private readonly ILogger _logger;
        private readonly IEventPublisher _eventPublisher;
        private readonly IWorkContext _workContext;
        private readonly IStoreMappingService _storeMappingService;
        private readonly IStoreService _storeService;
        public CheckOrderStatusService(IRepository<CheckOrderStatusLog> checkOrderStatusRepository, 
            ILogger logger, 
            IEventPublisher eventPublisher, 
            IWorkContext workContext,
            IStoreMappingService storeMappingService,
            IStoreService storeService)
        {
            _checkOrderStatusRepository = checkOrderStatusRepository;
            _logger = logger;
            _eventPublisher = eventPublisher;
            _workContext = workContext;
            _storeMappingService = storeMappingService;
            _storeService = storeService;
        }
        public async Task InsertOrderStatusLogRecordAsync(CheckOrderStatusLog checkOrderStatusLog)
        {
            if (checkOrderStatusLog == null)
            { throw new ArgumentNullException(nameof(checkOrderStatusLog)); }
            try
            {
                await _checkOrderStatusRepository.InsertAsync(checkOrderStatusLog);
                //event notification
                await _eventPublisher.EntityInsertedAsync(checkOrderStatusLog);
            }
            catch (Exception exception)
            {
                //log full error
                await _logger.ErrorAsync($"CheckOrderStatus error: {exception.Message}.", exception, await _workContext.GetCurrentCustomerAsync());
            }
            
        }

        public virtual async Task<IPagedList<CheckOrderStatusLog>> GetOrderStatusCheckLogAsync(int searchStoreId = 0, DateTime? createdFromUtc = null, DateTime? createdToUtc = null,
            int pageIndex = 0, int pageSize = int.MaxValue)
        {
            //get all logs 
            var query = _checkOrderStatusRepository.Table;

            //filter by dates
            if (createdFromUtc.HasValue)
                query = query.Where(logItem => logItem.DateCreatedUtc >= createdFromUtc.Value);
            if (createdToUtc.HasValue)
                query = query.Where(logItem => logItem.DateCreatedUtc <= createdToUtc.Value);

            //filter by store
            if (searchStoreId > 0)
                query = query.Where(logItem => logItem.StoreId == searchStoreId);
            //order log records
            query = query.OrderByDescending(logItem => logItem.DateCreatedUtc).ThenByDescending(logItem => logItem.Id);

            //return paged log
            return await query.ToPagedListAsync(pageIndex, pageSize);
        }

        public virtual async Task DeleteLogAsync(int[] ids)
        {
            await _checkOrderStatusRepository.DeleteAsync(logItem => ids.Contains(logItem.Id));
        }

        public virtual async Task SaveStoreMappingsAsync(Topic topic, TopicModel model)
        {
            topic.LimitedToStores = model.SelectedStoreIds.Any();

            var existingStoreMappings = await _storeMappingService.GetStoreMappingsAsync(topic);
            var allStores = await _storeService.GetAllStoresAsync();
            foreach (var store in allStores)
            {
                if (model.SelectedStoreIds.Contains(store.Id))
                {
                    //new store
                    if (existingStoreMappings.Count(sm => sm.StoreId == store.Id) == 0)
                        await _storeMappingService.InsertStoreMappingAsync(topic, store.Id);
                }
                else
                {
                    //remove store
                    var storeMappingToDelete = existingStoreMappings.FirstOrDefault(sm => sm.StoreId == store.Id);
                    if (storeMappingToDelete != null)
                        await _storeMappingService.DeleteStoreMappingAsync(storeMappingToDelete);
                }
            }
        }

    }
}
