﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Nop.Core;
using Nop.Plugin.Misc.CheckOrderStatus.Models;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Web.Framework.Components;

namespace Nop.Plugin.Misc.CheckOrderStatus.Components
{
    [ViewComponent(Name = "CheckOrderStatus")]
    public class CheckOrderStatusViewComponent : NopViewComponent
    {
        private readonly CheckOrderStatusSettings _checkOrderStatusSettings;
        private readonly ILocalizationService _localizationService;
        private readonly IStoreContext _storeContext;
        private readonly IWorkContext _workContext;
        private readonly ISettingService _settingService;

        public CheckOrderStatusViewComponent(CheckOrderStatusSettings checkOrderStatusSettings,
            ILocalizationService localizationService,
            IStoreContext storeContext,
            IWorkContext workContext,
            ISettingService settingService)
        {
            _checkOrderStatusSettings = checkOrderStatusSettings;
            _localizationService = localizationService;
            _storeContext = storeContext;
            _workContext = workContext;
            _settingService = settingService;
        }

        public async Task<IViewComponentResult> InvokeAsync(string widgetZone, object additionalData)
        {
            
            var checkOrderStatusSettings = await _settingService.LoadSettingAsync<CheckOrderStatusSettings>((await _storeContext.GetCurrentStoreAsync()).Id);
            if (!checkOrderStatusSettings.Enabled)
                return Content("");
            var model = new CheckOrderStatusModel
            {
                CustomerInstructions = checkOrderStatusSettings.CustomerInstructions,
                DisplayCaptcha = checkOrderStatusSettings.DisplayCaptcha,
                CustomerNote = checkOrderStatusSettings.CustomerNote                                                 
            };

            return View("~/Plugins/Misc.OrderStatus/Views/CheckOrderStatus.cshtml", model);
        }
    }
}
