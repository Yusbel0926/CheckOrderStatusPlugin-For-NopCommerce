﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Core;
using Nop.Core.Domain.Security;
using Nop.Plugin.Misc.CheckOrderStatus.Domain;
using Nop.Plugin.Misc.CheckOrderStatus.Models;
using Nop.Plugin.Misc.CheckOrderStatus.Services;
using Nop.Services.Common;
using Nop.Services.Configuration;
using Nop.Services.Customers;
using Nop.Services.Helpers;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Messages;
using Nop.Services.Orders;
using Nop.Services.Security;
using Nop.Services.Seo;
using Nop.Services.Stores;
using Nop.Services.Topics;
using Nop.Web.Factories;
using Nop.Web.Framework;
using Nop.Web.Framework.Controllers;
using Nop.Web.Framework.Models.Extensions;
using Nop.Web.Framework.Mvc.Filters;
using System.Linq;
using System.Collections.Generic;
using Nop.Web.Areas.Admin.Models.Topics;
using Nop.Web.Areas.Admin.Factories;
using IOrderModelFactory = Nop.Web.Factories.IOrderModelFactory;

namespace Nop.Plugin.Misc.CheckOrderStatus.Controllers
{
    
    public class CheckOrderStatusController : BasePluginController
    {
        private readonly IOrderService _orderService;
        private readonly ICustomerService _customerService;
        private readonly ISettingService _settingService;
        private readonly CheckOrderStatusService _checkOrderStatusServices;
        private readonly ILocalizationService _localizationService;
        private readonly IStoreContext _storeContext;
        private readonly IPermissionService _permissionService;
        private readonly INotificationService _notificationService;
        private readonly IOrderModelFactory _orderModelFactory;
        private readonly IDateTimeHelper _dateTimeHelper;
        private readonly ITopicService _topicService;
        //private readonly IUrlRecordService _urlRecordService;
        //private readonly ICustomerActivityService _customerActivityService;
        private readonly IWorkContext _workContext;
        private readonly IGenericAttributeService _genericAttributeService;
        private readonly IStoreService _storeService;
        private readonly CaptchaSettings _captchaSettings;
        private readonly Web.Areas.Admin.Factories.ITopicModelFactory _topicModelFactory;
        private readonly Web.Areas.Admin.Factories.IBaseAdminModelFactory _baseAdminModelFactory;
        public CheckOrderStatusController(INotificationService notificationService, 
            CheckOrderStatusService checkOrderStatusServices, 
            IOrderService orderService, 
            ICustomerService customerService,
            ILocalizationService localizationService,
           IStoreContext storeContext,
           IPermissionService permissionService,
           ISettingService settingService,
           IOrderModelFactory orderModelFactory,
           IDateTimeHelper dateTimeHelper,
           ITopicService topicService,
           IWorkContext workContext,
           IGenericAttributeService genericAttributeService,
           IStoreService storeService,
           CaptchaSettings captchaSettings,
            Web.Areas.Admin.Factories.ITopicModelFactory topicModelFactory,
            Web.Areas.Admin.Factories.IBaseAdminModelFactory baseAdminModelFactory)
        {
            _notificationService = notificationService;
            _customerService = customerService;
            _checkOrderStatusServices = checkOrderStatusServices;
            _orderService = orderService;
            _localizationService = localizationService;
            _storeContext = storeContext;
            _permissionService = permissionService;
            _settingService = settingService;
            _orderModelFactory = orderModelFactory;
            _dateTimeHelper = dateTimeHelper;
            _topicService = topicService;
            _workContext = workContext;
            _genericAttributeService = genericAttributeService;
            _storeService = storeService;
            _captchaSettings = captchaSettings;
            _topicModelFactory = topicModelFactory;
            _baseAdminModelFactory = baseAdminModelFactory;
        }
        [Area(AreaNames.ADMIN)]
        [AuthorizeAdmin]
        [AutoValidateAntiforgeryToken]
        public async Task<IActionResult> Configure()
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManagePlugins))
                return AccessDeniedView();

            //load settings for a chosen store scope
            var storeScope = await _storeContext.GetActiveStoreScopeConfigurationAsync();
            var checkOrderStatusSettings = await _settingService.LoadSettingAsync<CheckOrderStatusSettings>(storeScope);

            var model = new ConfigurationModel();
            if (!string.IsNullOrEmpty(checkOrderStatusSettings.PageTitle))
            {
                model = new ConfigurationModel
                {
                    Enabled = checkOrderStatusSettings.Enabled,
                    PageTitle = checkOrderStatusSettings.PageTitle,
                    CustomerInstructions = checkOrderStatusSettings.CustomerInstructions,
                    CustomerNote = checkOrderStatusSettings.CustomerNote,
                    DisplayCaptcha = checkOrderStatusSettings.DisplayCaptcha,
                    IncludeInFooterColumn1 = checkOrderStatusSettings.IncludeInFooterColumn1,
                    IncludeInFooterColumn2 = checkOrderStatusSettings.IncludeInFooterColumn2,
                    IncludeInFooterColumn3 = checkOrderStatusSettings.IncludeInFooterColumn3,
                    IncludeInTopMenu = checkOrderStatusSettings.IncludeInTopMenu,
                    EnableLogging = checkOrderStatusSettings.EnableLogging,
                    MetaTitle = checkOrderStatusSettings.MetaTitle,
                    MetaDescription = checkOrderStatusSettings.MetaDescription,
                    MetaKeywords = checkOrderStatusSettings.MetaKeywords
                };

            }
            else
            {
                model = new ConfigurationModel
                {
                    Enabled= CheckOrderStatusDefaults.Enabled,
                    PageTitle = CheckOrderStatusDefaults.PageTitle,
                    CustomerInstructions = CheckOrderStatusDefaults.CustomerInstructions,
                    CustomerNote = CheckOrderStatusDefaults.CustomerNote,
                    DisplayCaptcha = CheckOrderStatusDefaults.DisplayCaptcha,
                    IncludeInFooterColumn1 = CheckOrderStatusDefaults.IncludeInFooterColumn1,
                    IncludeInFooterColumn2 = CheckOrderStatusDefaults.IncludeInFooterColumn2,
                    IncludeInFooterColumn3 = CheckOrderStatusDefaults.IncludeInFooterColumn3,
                    IncludeInTopMenu = CheckOrderStatusDefaults.IncludeInTopMenu,
                    EnableLogging = CheckOrderStatusDefaults.EnableLogging,
                    MetaTitle = CheckOrderStatusDefaults.MetaTitle,
                    MetaDescription = CheckOrderStatusDefaults.MetaDescription,
                    MetaKeywords = CheckOrderStatusDefaults.MetaKeywords

                };
            }
            
            await _baseAdminModelFactory.PrepareStoresAsync(model.AvailableStores);
            var checkOrderStatusTopic = await _topicService.GetTopicBySystemNameAsync("OrderStatusCheck");
            var checkOrderStatusTopicModel = await _topicModelFactory.PrepareTopicModelAsync(new TopicModel(), checkOrderStatusTopic);
            model.SelectedStoreIds = checkOrderStatusTopicModel.SelectedStoreIds;
            model.HideGeneralBlock = await _genericAttributeService.GetAttributeAsync<bool>(await _workContext.GetCurrentCustomerAsync(), CheckOrderStatusDefaults.HideGeneralBlock);
            model.HideLogBlock = await _genericAttributeService.GetAttributeAsync<bool>(await _workContext.GetCurrentCustomerAsync(), CheckOrderStatusDefaults.HideLogBlock);
            
            //prepare ckeck order status log model
            model.CheckOrderStatusLogSearchModel.AvailableStores.Add(new SelectListItem { Text = await _localizationService.GetResourceAsync("Admin.Configuration.Settings.StoreScope.AllStores"), Value = "0" });
            foreach (var store in await _storeService.GetAllStoresAsync())
                model.CheckOrderStatusLogSearchModel.AvailableStores.Add(new SelectListItem { Text = store.Name, Value = store.Id.ToString() });

            model.CheckOrderStatusLogSearchModel.SetGridPageSize();
            model.ActiveStoreScopeConfiguration = storeScope;
            
            if (storeScope > 0)
            {
                model.Enabled_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.Enabled, storeScope);
                model.CustomerInstructions_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.CustomerInstructions, storeScope);
                model.PageTitle_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.PageTitle, storeScope);
                model.MetaTitle_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.MetaTitle, storeScope);
                model.MetaDescription_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.MetaDescription, storeScope);
                model.MetaKeywords_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.MetaKeywords, storeScope);
                model.CustomerNote_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.CustomerNote, storeScope);
                model.DisplayCaptcha_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.DisplayCaptcha, storeScope);
                model.IncludeInFooterColumn1_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.IncludeInFooterColumn1, storeScope);
                model.IncludeInFooterColumn2_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.IncludeInFooterColumn2, storeScope);
                model.IncludeInFooterColumn3_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.IncludeInFooterColumn3, storeScope);
                model.IncludeInTopMenu_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.IncludeInTopMenu, storeScope);
                model.EnableLogging_OverrideForStore = await _settingService.SettingExistsAsync(checkOrderStatusSettings, x => x.EnableLogging, storeScope);
            }

            return View("~/Plugins/Misc.CheckOrderStatus/Views/Configure.cshtml", model);
        }

        [HttpPost]
        [Area(AreaNames.ADMIN)]
        [AuthorizeAdmin]
        [AutoValidateAntiforgeryToken]
        public async Task<IActionResult> Configure(ConfigurationModel model)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManagePlugins))
                return AccessDeniedView();

            if (!ModelState.IsValid)
                return await Configure();

            //load settings for a chosen store scope
            var storeScope = await _storeContext.GetActiveStoreScopeConfigurationAsync();
            var checkOrderStatusSettings = await _settingService.LoadSettingAsync<CheckOrderStatusSettings>(storeScope);

            //save settings
            checkOrderStatusSettings.Enabled = model.Enabled;
            checkOrderStatusSettings.CustomerInstructions = model.CustomerInstructions;
            checkOrderStatusSettings.PageTitle = model.PageTitle;
            checkOrderStatusSettings.MetaTitle = model.MetaTitle;
            checkOrderStatusSettings.MetaDescription = model.MetaDescription;
            checkOrderStatusSettings.MetaKeywords = model.MetaKeywords;
            checkOrderStatusSettings.CustomerNote = model.CustomerNote;
            checkOrderStatusSettings.DisplayCaptcha = model.DisplayCaptcha;
            checkOrderStatusSettings.IncludeInFooterColumn1 = model.IncludeInFooterColumn1;
            checkOrderStatusSettings.IncludeInFooterColumn2 = model.IncludeInFooterColumn2;
            checkOrderStatusSettings.IncludeInFooterColumn3 = model.IncludeInFooterColumn3;
            checkOrderStatusSettings.IncludeInTopMenu = model.IncludeInTopMenu;
            checkOrderStatusSettings.IncludeInSiteMap = model.IncludeInSiteMap;
            checkOrderStatusSettings.DisplayOrder = model.DisplayOrder;
            checkOrderStatusSettings.EnableLogging = model.EnableLogging;
            /* We do not clear cache after each setting update.
             * This behavior can increase performance because cached settings will not be cleared 
             * and loaded from database after each update */
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.Enabled, model.Enabled_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.CustomerInstructions, model.CustomerInstructions_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.PageTitle, model.PageTitle_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.MetaTitle, model.MetaTitle_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.MetaDescription, model.MetaDescription_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.MetaKeywords, model.MetaKeywords_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.CustomerNote, model.CustomerNote_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.DisplayCaptcha, model.DisplayCaptcha_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.IncludeInFooterColumn1, model.IncludeInFooterColumn1_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.IncludeInFooterColumn2, model.IncludeInFooterColumn2_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.IncludeInFooterColumn3, model.IncludeInFooterColumn3_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.IncludeInTopMenu, model.IncludeInTopMenu_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.IncludeInSiteMap, model.IncludeInSiteMap_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.DisplayOrder, model.DisplayOrder_OverrideForStore, storeScope, false);
            await _settingService.SaveSettingOverridablePerStoreAsync(checkOrderStatusSettings, x => x.EnableLogging, model.EnableLogging_OverrideForStore, storeScope, false);
            /*
             //link on footer column
              if (checkOrderStatusSettings.IncludeInFooterColumn1 || checkOrderStatusSettings.IncludeInFooterColumn2 || checkOrderStatusSettings.IncludeInFooterColumn3 || checkOrderStatusSettings.IncludeInTopMenu)
            {
                //check if topic exist
                var checkOrderStatusTopic = await _topicService.GetTopicBySystemNameAsync("OrderStatusCheck");
                if (checkOrderStatusTopic != null)
                {
                    checkOrderStatusTopic.IncludeInFooterColumn1 = checkOrderStatusSettings.IncludeInFooterColumn1;
                    checkOrderStatusTopic.IncludeInFooterColumn2 = checkOrderStatusSettings.IncludeInFooterColumn2;
                    checkOrderStatusTopic.IncludeInFooterColumn3 = checkOrderStatusSettings.IncludeInFooterColumn3;
                    checkOrderStatusTopic.IncludeInTopMenu = checkOrderStatusSettings.IncludeInTopMenu;
                    checkOrderStatusTopic.IncludeInSitemap = checkOrderStatusSettings.IncludeInSiteMap;
                    checkOrderStatusTopic.DisplayOrder = checkOrderStatusSettings.DisplayOrder;
                    checkOrderStatusTopic.Title = checkOrderStatusSettings.PageTitle;
                    checkOrderStatusTopic.MetaTitle = checkOrderStatusSettings.MetaTitle;
                    checkOrderStatusTopic.MetaDescription = checkOrderStatusSettings.MetaDescription;
                    checkOrderStatusTopic.MetaKeywords = checkOrderStatusSettings.MetaKeywords;
                    checkOrderStatusTopic.LimitedToStores = model.SelectedStoreIds.Any();
                    checkOrderStatusTopic.Published = model.Enabled;
                    
                    await _topicService.UpdateTopicAsync(checkOrderStatusTopic);
                    var checkOrderStatusTopicModel = await _topicModelFactory.PrepareTopicModelAsync(new TopicModel(), checkOrderStatusTopic);

                    //stores
                    await _checkOrderStatusServices.SaveStoreMappingsAsync(checkOrderStatusTopic, checkOrderStatusTopicModel);
                    //activity log
                    await _customerActivityService.InsertActivityAsync("EditTopic",
                        string.Format(await _localizationService.GetResourceAsync("ActivityLog.EditTopic"), checkOrderStatusTopic.Title ?? checkOrderStatusTopic.SystemName), checkOrderStatusTopic);
                }
                else
                {
                    var topic = new Topic()
                    {
                        SystemName = "OrderStatusCheck",
                        AccessibleWhenStoreClosed = true,
                        IncludeInSitemap = checkOrderStatusSettings.IncludeInSiteMap,
                        Body = "",
                        Title = checkOrderStatusSettings.PageTitle,
                        MetaTitle = checkOrderStatusSettings.MetaTitle,
                        MetaKeywords = checkOrderStatusSettings.MetaKeywords,
                        MetaDescription = checkOrderStatusSettings.MetaDescription,
                        DisplayOrder = 0,
                        IncludeInFooterColumn1 = checkOrderStatusSettings.IncludeInFooterColumn1,
                        IncludeInFooterColumn2 = checkOrderStatusSettings.IncludeInFooterColumn2,
                        IncludeInFooterColumn3 = checkOrderStatusSettings.IncludeInFooterColumn3,
                        IsPasswordProtected = false,
                        LimitedToStores = model.SelectedStoreIds.Any(),
                        Published = checkOrderStatusSettings.Enabled,
                        TopicTemplateId = 1
                    };
                    await _topicService.InsertTopicAsync(topic);
                    //prepare topic model
                    var checkOrderStatusTopicModel = await _topicModelFactory.PrepareTopicModelAsync(new TopicModel(), topic);
                    checkOrderStatusTopicModel.SelectedStoreIds = model.SelectedStoreIds;
                    //stores
                    await _checkOrderStatusServices.SaveStoreMappingsAsync(topic, checkOrderStatusTopicModel);
                    await _urlRecordService.SaveSlugAsync(topic, "CheckOrderStatus", 0);
                    //activity log
                    await _customerActivityService.InsertActivityAsync("AddNewTopic",
                        string.Format(await _localizationService.GetResourceAsync("ActivityLog.AddNewTopic"), topic.Title ?? topic.SystemName), topic);
                }
            }
             */


            //now clear settings cache
            await _settingService.ClearCacheAsync();


            _notificationService.SuccessNotification(await _localizationService.GetResourceAsync("Admin.Plugins.Saved"));

            return await Configure();
            
        }
        [HttpsRequirement]
        [CheckAccessClosedStore(true)]
        [CheckAccessPublicStore(true)]        
        public async Task<IActionResult> Check()
        {

            //load settings for a chosen store scope
            var storeScope = await _storeContext.GetCurrentStoreAsync();
            var orderStatusSettings = await _settingService.LoadSettingAsync<CheckOrderStatusSettings>(storeScope.Id);
            var captchaSettings = await _settingService.LoadSettingAsync<CaptchaSettings>(storeScope.Id);
            orderStatusSettings.DisplayCaptcha = orderStatusSettings.DisplayCaptcha && captchaSettings.Enabled;
            if (orderStatusSettings.Enabled)
            {
                var model = new CheckOrderStatusModel
                {
                    PageTitle = orderStatusSettings.PageTitle,
                    CustomerInstructions = orderStatusSettings.CustomerInstructions,
                    CustomerNote = orderStatusSettings.CustomerNote,
                    DisplayCaptcha = orderStatusSettings.DisplayCaptcha && captchaSettings.Enabled,
                    MetaTitle = orderStatusSettings.MetaTitle,
                    MetaDescription = orderStatusSettings.MetaDescription,
                    MetaKeywords = orderStatusSettings.MetaKeywords

                };
                return View("~/Plugins/Misc.CheckOrderStatus/Views/CheckOrderStatus.cshtml", model);
            }
            else
                return Content(string.Empty);
            
        }

        [HttpPost, ActionName("GetOrder")]
        [ValidateCaptcha]
        //available even when a store is closed
        [CheckAccessClosedStore(ignore: true)]
        //available even when navigation is not allowed
        [CheckAccessPublicStore(ignore: true)]
        [FormValueRequired("submit-checkorderstatus")]        
        public async Task<IActionResult> GetOrder(CheckOrderStatusModel checkOrderStatusModel, bool captchaValid)
        {
            var storeScope = await _storeContext.GetCurrentStoreAsync();
            var checkOrderStatusSettings = await _settingService.LoadSettingAsync<CheckOrderStatusSettings>(storeScope.Id);
            var captchaSettings = await _settingService.LoadSettingAsync<CaptchaSettings>(storeScope.Id);
            //validate CAPTCHA
            if (_captchaSettings.Enabled && checkOrderStatusSettings.DisplayCaptcha && !captchaValid)
            {
                ModelState.AddModelError("EmailMismatch", await _localizationService.GetResourceAsync("Common.WrongCaptchaMessage"));
            }

            if (!ModelState.IsValid)
                return await Check();
            checkOrderStatusModel.PageTitle = checkOrderStatusSettings.PageTitle;
            checkOrderStatusModel.CustomerInstructions = checkOrderStatusSettings.CustomerInstructions;
            checkOrderStatusModel.CustomerNote = checkOrderStatusSettings.CustomerNote;
            checkOrderStatusModel.DisplayCaptcha = checkOrderStatusSettings.DisplayCaptcha && captchaSettings.Enabled;
            checkOrderStatusModel.MetaTitle = checkOrderStatusSettings.MetaTitle;
            checkOrderStatusModel.MetaDescription = checkOrderStatusSettings.MetaDescription;
            checkOrderStatusModel.MetaKeywords = checkOrderStatusSettings.MetaKeywords;
            var order = await _orderService.GetOrderByCustomOrderNumberAsync(checkOrderStatusModel.CustomOrderNumber);
            if (order != null)
            {
                var orderCustomer = await _customerService.GetCustomerByIdAsync(order.CustomerId);
                var customerBillingAddress = await _customerService.GetCustomerBillingAddressAsync(orderCustomer);
                if (checkOrderStatusModel.CustomerEmail.ToLower() == customerBillingAddress.Email.ToLower())
                {
                    if (checkOrderStatusSettings.EnableLogging)
                    {
                        var osl = new CheckOrderStatusLog()
                        {
                            OrderId = order.Id,
                            CustomOrderNumber = checkOrderStatusModel.CustomOrderNumber,
                            CustomerEmail = checkOrderStatusModel.CustomerEmail,
                            DateCreatedUtc = DateTime.UtcNow,
                            CheckStatus = "Success",
                            StoreId = storeScope.Id
                        };
                        await _checkOrderStatusServices.InsertOrderStatusLogRecordAsync(osl);
                    }
                        
                    var model = await _orderModelFactory.PrepareOrderDetailsModelAsync(order);
                    //return RedirectToRoute("OrderDetails", new { orderId = osr.OrderId });
                    return View("~/Views/Order/Details.cshtml", model);
                }
                else
                {
                    
                    if (checkOrderStatusSettings.EnableLogging)
                    {
                        var osl = new CheckOrderStatusLog()
                        {
                            OrderId = order.Id,
                            CustomOrderNumber = checkOrderStatusModel.CustomOrderNumber,
                            CustomerEmail = checkOrderStatusModel.CustomerEmail,
                            DateCreatedUtc = DateTime.UtcNow,
                            CheckStatus = "Fail",
                            StoreId = storeScope.Id
                        };
                        await _checkOrderStatusServices.InsertOrderStatusLogRecordAsync(osl);
                    }
                       
                    ModelState.AddModelError("EmailMismatch", "Email does not match to email address used to place order");
                    return View("~/Plugins/Misc.CheckOrderStatus/Views/CheckOrderStatus.cshtml", checkOrderStatusModel);
                }
            }
            else
            {
                ModelState.AddModelError("EmailMismatch", "Order number not found");
                return View("~/Plugins/Misc.CheckOrderStatus/Views/CheckOrderStatus.cshtml", checkOrderStatusModel);
            }
        }

        [HttpPost]
        [Area(AreaNames.ADMIN)]
        [AuthorizeAdmin]
        [AutoValidateAntiforgeryToken]
        public async Task<IActionResult> LogList(CheckOrderStatusLogSearchModel searchModel)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManagePlugins))
                return await AccessDeniedDataTablesJson();

            //prepare filter parameters
            var createdFromValue = searchModel.CreatedFrom.HasValue
                ? (DateTime?)_dateTimeHelper.ConvertToUtcTime(searchModel.CreatedFrom.Value, await _dateTimeHelper.GetCurrentTimeZoneAsync())
                : null;
            var createdToValue = searchModel.CreatedTo.HasValue
                ? (DateTime?)_dateTimeHelper.ConvertToUtcTime(searchModel.CreatedTo.Value, await _dateTimeHelper.GetCurrentTimeZoneAsync()).AddDays(1)
                : null;
            var searchStoreId = searchModel.SearchStoreId;
            //get order status check log
            var records = await _checkOrderStatusServices.GetOrderStatusCheckLogAsync(searchStoreId, createdFromUtc: createdFromValue, createdToUtc: createdToValue,
                pageIndex: searchModel.Page - 1, pageSize: searchModel.PageSize);

            //prepare grid model
            var gridModel = await new CheckOrderStatusLogListModel().PrepareToGridAsync(searchModel, records, () =>
            {
                return records.SelectAwait(async record => 
                {
                    var model = new CheckOrderStatusLogModel
                    {
                        Id = record.Id,
                        OrderId = record.OrderId,
                        CustomOrderNumber = record.CustomOrderNumber,
                        CustomerEmail = record.CustomerEmail,
                        CheckStatus = record.CheckStatus,
                        DateCreatedUtc = _dateTimeHelper.ConvertToUtcTime(record.DateCreatedUtc, await _dateTimeHelper.GetCurrentTimeZoneAsync()),
                        Store = (await _storeService.GetStoreByIdAsync(record.StoreId)).Name
                    };
                    return model;
                });
            });
            return Json(gridModel);
        }
        [HttpPost]
        [Area(AreaNames.ADMIN)]
        [AuthorizeAdmin]
        [AutoValidateAntiforgeryToken]
        public async Task<IActionResult> DeleteSelectedAsync(ICollection<int> selectedIds)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManagePlugins))
                return  AccessDeniedView();

            if (selectedIds != null)
                await _checkOrderStatusServices.DeleteLogAsync(selectedIds.ToArray());

            return Json(new { Result = true });
        }       
    }
}
