﻿using System;
using Nop.Core;

namespace Nop.Plugin.Misc.CheckOrderStatus.Domain
{
    public partial class CheckOrderStatusLog : BaseEntity
    {
        public int OrderId { get; set; }
        public string CustomOrderNumber { get; set; }
        public string CustomerEmail { get; set; }
        public DateTime DateCreatedUtc { get; set; }
        public string CheckStatus { get; set; }
        public int StoreId { get; set; }
    }
}
