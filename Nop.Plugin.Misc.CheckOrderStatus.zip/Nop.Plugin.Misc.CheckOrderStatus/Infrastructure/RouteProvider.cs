﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Nop.Web.Framework;
using Nop.Web.Framework.Mvc.Routing;

namespace Nop.Plugin.Misc.CheckOrderStatus.Infrastructure
{
    public partial class RouteProvider : IRouteProvider
    {
        public void RegisterRoutes(IEndpointRouteBuilder endpointRouteBuilder)
        {
            endpointRouteBuilder.MapControllerRoute("CheckOrderStatusConfigure", "Admin/CheckOrderStatus/Configure", new { controller = "CheckOrderStatus", action = "Configure", area = AreaNames.ADMIN });
            endpointRouteBuilder.MapControllerRoute("CheckOrderStatusCheck", "CheckOrderStatus", new { controller = "CheckOrderStatus", action = "Check" });
            endpointRouteBuilder.MapControllerRoute("CheckOrderStatusLogList", "Admin/CheckOrderStatus/LogList", new { controller = "CheckOrderStatus", action = "LogList", area = AreaNames.ADMIN });

        }
        /// <summary>
        /// Gets a priority of route provider
        /// </summary>
        public int Priority => -1;
    }
}
