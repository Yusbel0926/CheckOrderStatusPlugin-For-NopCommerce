﻿using System;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Misc.CheckOrderStatus.Models
{
    public record CheckOrderStatusLogModel : BaseNopEntityModel
    {
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.OrderId")]
        public int OrderId { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CustomOrderNumber")]
        public string CustomOrderNumber { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CustomerEmail")]
        public string CustomerEmail { get; set; }

        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CheckStatus")]

        public string CheckStatus { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CreatedDate")]
        public DateTime DateCreatedUtc { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.Store")]
        public string Store { get; set; }
    }
}
