﻿using Nop.Web.Framework.Models;

namespace Nop.Plugin.Misc.CheckOrderStatus.Models
{
    public record CheckOrderStatusLogListModel : BasePagedListModel<CheckOrderStatusLogModel>
    {

    }
}
