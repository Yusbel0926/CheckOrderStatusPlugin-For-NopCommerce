﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Misc.CheckOrderStatus.Models
{
    public record CheckOrderStatusLogSearchModel : BaseSearchModel
    {
        public CheckOrderStatusLogSearchModel()
        {
            AvailableStores = new List<SelectListItem>();
        }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CreatedFrom")]
        [UIHint("DateNullable")]
        public DateTime? CreatedFrom { get; set; }

        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CreatedTo")]
        [UIHint("DateNullable")]
        public DateTime? CreatedTo { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.Store")]
        public int SearchStoreId { get; set; }
        public IList<SelectListItem> AvailableStores { get; set; }
    }
}
