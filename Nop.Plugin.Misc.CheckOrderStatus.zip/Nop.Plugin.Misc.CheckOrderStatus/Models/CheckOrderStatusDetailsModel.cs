﻿using Nop.Web.Framework.Models;
using Nop.Web.Models.Order;

namespace Nop.Plugin.Misc.CheckOrderStatus.Models
{
    public record CheckOrderStatusDetailsModel : BaseNopModel
    {
        public OrderDetailsModel OrderStatusDetails { get; set; }
    }
}
