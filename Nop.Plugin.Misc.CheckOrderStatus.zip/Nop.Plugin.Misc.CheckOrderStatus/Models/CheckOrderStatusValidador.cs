﻿using FluentValidation;
using Nop.Services.Localization;
using Nop.Web.Framework.Validators;

namespace Nop.Plugin.Misc.CheckOrderStatus.Models
{
    public class CheckOrderStatusValidador : BaseNopValidator<CheckOrderStatusModel>
    {
        public CheckOrderStatusValidador(ILocalizationService localizationService)
        {
            RuleFor(x => x.CustomOrderNumber)
                .NotEmpty()
                .WithMessageAwait(localizationService.GetResourceAsync("Plugins.Misc.CheckOrderStatus.CustomOrderNumber.Required")).Matches("^\\d+$").WithMessage("Invalid order number");
            RuleFor(x => x.CustomerEmail)
                .NotEmpty()
                .WithMessageAwait(localizationService.GetResourceAsync("Plugins.Misc.CheckOrderStatus.CustomerEmail.Required"));
        }
    }
}
