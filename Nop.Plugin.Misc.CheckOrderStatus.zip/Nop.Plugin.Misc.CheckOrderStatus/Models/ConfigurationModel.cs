﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.Rendering;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Misc.CheckOrderStatus.Models
{
    public record ConfigurationModel : BaseNopModel
    {
        public ConfigurationModel()
        {
            SelectedStoreIds = new List<int>();
            AvailableStores = new List<SelectListItem>();
            CheckOrderStatusLogSearchModel = new CheckOrderStatusLogSearchModel();
        }
        public int ActiveStoreScopeConfiguration { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.Enabled")]
        public bool Enabled { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.PageTitle")]
        public bool Enabled_OverrideForStore { get; set; }
        
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.MetaTitle")]
        public string PageTitle { get; set; }
        public bool PageTitle_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.MetaTitle")]
        public string MetaTitle { get; set; }
        public bool MetaTitle_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.MetaDescription")]
        public string MetaDescription { get; set; }
        public bool MetaDescription_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.MetaKeywords")]
        public string MetaKeywords { get; set; }
        public bool MetaKeywords_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CustomerInstructions")]
        public string CustomerInstructions { get; set; }
        public bool CustomerInstructions_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CustomerNote")]
        public string CustomerNote { get; set; }
        public bool CustomerNote_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.DisplayCaptcha")]
        public bool DisplayCaptcha { get; set; }
        public bool DisplayCaptcha_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.IncludeInFooterColumn1")]
        public bool IncludeInFooterColumn1 { get; set; }
        public bool IncludeInFooterColumn1_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.IncludeInFooterColumn2")]
        public bool IncludeInFooterColumn2 { get; set; }
        public bool IncludeInFooterColumn2_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.IncludeInFooterColumn3")]
        public bool IncludeInFooterColumn3 { get; set; }
        public bool IncludeInFooterColumn3_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.IncludeInTopMenu")]
        public bool IncludeInTopMenu { get; set; }
        public bool IncludeInTopMenu_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.IncludeInSiteMap")]
        public bool IncludeInSiteMap { get; set; }
        public bool IncludeInSiteMap_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.DisplayOrder")]
        public int DisplayOrder { get; set; }
        public bool DisplayOrder_OverrideForStore { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.EnableLogging")]
        public bool EnableLogging { get; set; }
        public bool EnableLogging_OverrideForStore { get; set; }
        //store mapping
        [NopResourceDisplayName("Admin.ContentManagement.Topics.Fields.LimitedToStores")]
        public IList<int> SelectedStoreIds { get; set; }
        public IList<SelectListItem> AvailableStores { get; set; }
        public bool HideGeneralBlock { get; set; }
        public bool HideLogBlock { get; set; }
        public CheckOrderStatusLogSearchModel CheckOrderStatusLogSearchModel { get; set; }
    }
}
