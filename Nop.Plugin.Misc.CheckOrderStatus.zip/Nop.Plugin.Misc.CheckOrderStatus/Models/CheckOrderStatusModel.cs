﻿using System;
using Nop.Web.Framework.Models;
using Nop.Web.Framework.Mvc.ModelBinding;

namespace Nop.Plugin.Misc.CheckOrderStatus.Models
{
    public record CheckOrderStatusModel : BaseNopModel
    {
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CustomOrderNumber")]
        public string CustomOrderNumber { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CustomerEmail")]
        public string CustomerEmail { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.EmailMismatch")]
        public string EmailMismatch { get; set; }
        [NopResourceDisplayName("Plugins.Misc.CheckOrderStatus.CustomerInstructions")]

        public string ResponseMessage { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CustomerInstructions { get; set; }
        public string PageTitle { get; set; }
        public string MetaTitle { get; set; }
        public string MetaDescription { get; set; }
        public string MetaKeywords { get; set; }
        public string CustomerNote { get; set; }
        public bool DisplayCaptcha { get; set; }
    }
}
