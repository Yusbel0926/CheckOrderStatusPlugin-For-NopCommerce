﻿using Nop.Core.Configuration;
namespace Nop.Plugin.Misc.CheckOrderStatus
{
    public class CheckOrderStatusSettings : ISettings
    {
        public bool Enabled { get; set; }
        public string PageTitle { get; set; }
        public string MetaTitle { get; set; }
        public string MetaDescription { get; set; }
        public string MetaKeywords { get; set; }
        public string CustomerInstructions { get; set; }
        public string CustomerNote { get; set; }
        public bool DisplayCaptcha { get; set; }
        public bool IncludeInFooterColumn1 { get; set; }
        public bool IncludeInFooterColumn2 { get; set; }
        public bool IncludeInFooterColumn3 { get; set; }
        public bool IncludeInTopMenu { get; set; }
        public bool IncludeInSiteMap { get; set; }
        public int DisplayOrder { get; set; }
        public bool EnableLogging { get; set; }
    }
}
