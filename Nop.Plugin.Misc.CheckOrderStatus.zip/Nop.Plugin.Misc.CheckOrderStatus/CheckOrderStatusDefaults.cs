﻿
namespace Nop.Plugin.Misc.CheckOrderStatus
{
    public class CheckOrderStatusDefaults
    {
        public static bool Enabled = false;
        public static string PageTitle = "Check Order Status";
        public static string MetaTitle = "Check Your Order Status Securely";
        public static string MetaDescription = "Check and track your order status here. Simply enter your order number, your email to find out how and when you'll receive your order!";
        public static string MetaKeywords = "Order, Shipment, Carrier,Shipping, Tracking, Status";
        public static string CustomerInstructions = "Enter your order information in the form below";
        public static string CustomerNote = "Your order number can be found on your order email confirmation";
        public static bool DisplayCaptcha = false;
        public static bool IncludeInFooterColumn1 = false;
        public static bool IncludeInFooterColumn2 = false;
        public static bool IncludeInFooterColumn3 = false;
        public static bool IncludeInTopMenu = false;
        public static bool IncludeInSiteMap = false;
        public static int DisplayOrder = 0;
        public static bool EnableLogging = false;
        public static string HideLogBlock => "CheckOrderStatus.HideLogBlock";
        public static string HideGeneralBlock => "CheckOrderStatus.HideGeneralBlock";
    }
}
