﻿using FluentMigrator.Builders.Create.Table;
using Nop.Data.Mapping.Builders;
using Nop.Plugin.Misc.CheckOrderStatus.Domain;

namespace Nop.Plugin.Misc.CheckOrderStatus.Data
{
    public class CheckOrderStatusLogBuilder : NopEntityBuilder<CheckOrderStatusLog>
    {
        public override void MapEntity(CreateTableExpressionBuilder table)
        {
            table
                .WithColumn(nameof(CheckOrderStatusLog.OrderId))
                .AsInt32()
                .WithColumn(nameof(CheckOrderStatusLog.CustomOrderNumber))
                .AsString()                
                .WithColumn(nameof(CheckOrderStatusLog.CustomerEmail))
                .AsString()
                .WithColumn(nameof(CheckOrderStatusLog.CheckStatus))
                .AsString()
                .WithColumn(nameof(CheckOrderStatusLog.DateCreatedUtc))
                .AsString()
                .WithColumn(nameof(CheckOrderStatusLog.StoreId))
                .AsInt32();
        }
    }
}
