﻿using FluentMigrator;
using Nop.Data.Extensions;
using Nop.Data.Migrations;
using Nop.Plugin.Misc.CheckOrderStatus.Domain;

namespace Nop.Plugin.Misc.CheckOrderStatus.Data
{
    
    [NopMigration("2021/07/27 08:40:55:1687551", "Misc.CheckOrderStatus base schema", MigrationProcessType.Installation)]
    public class SchemaMigration : AutoReversingMigration
    {
        public override void Up()
        {
            Create.TableFor<CheckOrderStatusLog>();
        }
    }
}
