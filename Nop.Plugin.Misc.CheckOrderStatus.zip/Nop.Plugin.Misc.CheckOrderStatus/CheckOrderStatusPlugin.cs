﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Routing;
using Nop.Core;
using Nop.Core.Domain.Seo;
using Nop.Core.Domain.Topics;
using Nop.Services.Configuration;
using Nop.Services.Localization;
using Nop.Services.Logging;
using Nop.Services.Plugins;
using Nop.Services.Security;
using Nop.Services.Seo;
using Nop.Services.Stores;
using Nop.Services.Topics;
using Nop.Web.Framework.Menu;

namespace Nop.Plugin.Misc.CheckOrderStatus
{
    public class CheckOrderStatusPlugin : BasePlugin, IAdminMenuPlugin
    {
        private readonly ILocalizationService _localizationService;
        private readonly IWebHelper _webHelper;
        private readonly ISettingService _settingService;
        private readonly IPermissionService _permissionService;
        private readonly ITopicService _topicService;       
        private readonly ICustomerActivityService _customerActivityService;
        private readonly IUrlRecordService _urlRecordService;
        private readonly IStoreContext _storeContext;        

        public CheckOrderStatusPlugin(ILocalizationService localizationService,
           IWebHelper webHelper,
           ISettingService settingService,
           IPermissionService permissionService,
           ITopicService topicService,           
           ICustomerActivityService customerActivityService,
           IUrlRecordService urlRecordService,
           IStoreContext storeContext)
        {
            _localizationService = localizationService;
            _webHelper = webHelper;
            _settingService = settingService;
            _permissionService = permissionService;
            _topicService = topicService;            
            _customerActivityService = customerActivityService;
            _urlRecordService = urlRecordService;
            _storeContext = storeContext;            
        }
        /// <summary>
        /// Gets a configuration page URL
        /// </summary>
        public override string GetConfigurationPageUrl()
        {
            return $"{_webHelper.GetStoreLocation()}Admin/CheckOrderStatus/Configure";
        }
        /// <summary>
        /// Gets a name of a view component for displaying plugin in public store ("payment info" checkout step)
        /// </summary>
        /// <returns>View component name</returns>
        public string GetPublicViewComponentName()
        {
            return "CheckOrderStatus";
        }

        public async Task ManageSiteMapAsync(SiteMapNode siteMapNode)
        {
            if (!await _permissionService.AuthorizeAsync(StandardPermissionProvider.ManagePlugins))
                return;

            var pluginNode = siteMapNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Underworks plugins");

            if (pluginNode == null)
            {
                var menuItem = new SiteMapNode()
                {
                    SystemName = "Underworks plugins",
                    Title = "Underworks plugins",
                    Visible = true,
                    IconClass = "fas fa-plug",
                };
                siteMapNode.ChildNodes.Add(menuItem);
            }
            pluginNode = siteMapNode.ChildNodes.FirstOrDefault(x => x.SystemName == "Underworks plugins");
            if (pluginNode != null)
            {
                var menuItem1 = new SiteMapNode()
                {
                    SystemName = "CheckOrderStatus",
                    Title = "Check Order Status",
                    Visible = true,
                    IconClass = "fa fa-list",
                };
                pluginNode.ChildNodes.Add(menuItem1);
                var pqNode = pluginNode.ChildNodes.FirstOrDefault(pluginNode => pluginNode.SystemName == "CheckOrderStatus");
                if (pqNode != null)
                {
                    var menuItem2 = new SiteMapNode()
                    {
                        SystemName = "CheckOrderStatus",
                        Title = "Configure",
                        ControllerName = "CheckOrderStatus",
                        ActionName = "Configure",
                        Visible = true,
                        IconClass = "fas fa-cogs",
                        RouteValues = new RouteValueDictionary() { { "area", "Admin" } },
                    };
                    pqNode.ChildNodes.Add(menuItem2);

                }
            }
        }
        public override async Task InstallAsync()
        {
            //settings 
            //load settings for a chosen store scope
            var storeScope = await _storeContext.GetActiveStoreScopeConfigurationAsync();
            var settings = await _settingService.LoadSettingAsync<CheckOrderStatusSettings>(storeScope);

            if (string.IsNullOrEmpty(settings.PageTitle))
            {
                settings = new CheckOrderStatusSettings()
                {
                    Enabled = CheckOrderStatusDefaults.Enabled,
                    PageTitle = CheckOrderStatusDefaults.PageTitle,
                    MetaTitle = CheckOrderStatusDefaults.MetaTitle,
                    MetaDescription = CheckOrderStatusDefaults.MetaDescription,
                    MetaKeywords = CheckOrderStatusDefaults.MetaKeywords,
                    CustomerInstructions = CheckOrderStatusDefaults.CustomerInstructions,
                    CustomerNote = CheckOrderStatusDefaults.CustomerNote,
                    DisplayCaptcha = CheckOrderStatusDefaults.DisplayCaptcha,
                    IncludeInFooterColumn1 = CheckOrderStatusDefaults.IncludeInFooterColumn1,
                    IncludeInFooterColumn2 = CheckOrderStatusDefaults.IncludeInFooterColumn2,
                    IncludeInFooterColumn3 = CheckOrderStatusDefaults.IncludeInFooterColumn3,
                    IncludeInSiteMap = CheckOrderStatusDefaults.IncludeInSiteMap,
                    IncludeInTopMenu = CheckOrderStatusDefaults.IncludeInTopMenu,
                    EnableLogging = CheckOrderStatusDefaults.EnableLogging,
                    DisplayOrder = 0
                };
                await _settingService.SaveSettingAsync(settings);
            }
            
            //topic
            //check if topic exist
            var checkOrderStatusTopic = await _topicService.GetTopicBySystemNameAsync("OrderStatusCheck");
            if (checkOrderStatusTopic == null)
            {
                var topic = new Topic()
                {
                    SystemName = "OrderStatusCheck",
                    AccessibleWhenStoreClosed = true,
                    IncludeInSitemap = settings.IncludeInSiteMap,
                    Body = "",
                    Title = settings.MetaTitle,
                    MetaTitle = settings.MetaTitle,
                    MetaKeywords = settings.MetaKeywords,
                    MetaDescription = settings.MetaDescription,
                    DisplayOrder = settings.DisplayOrder,
                    IncludeInFooterColumn1 = settings.IncludeInFooterColumn1,
                    IncludeInFooterColumn2 = settings.IncludeInFooterColumn2,
                    IncludeInFooterColumn3 = settings.IncludeInFooterColumn3,
                    IsPasswordProtected = false,
                    LimitedToStores = false,
                    Published = settings.Enabled,
                    TopicTemplateId = 1
                };
                await _topicService.InsertTopicAsync(topic);               
                await _urlRecordService.SaveSlugAsync(topic, "CheckOrderStatus", 0);
                
                //activity log
                await _customerActivityService.InsertActivityAsync("AddNewTopic",
                    string.Format(await _localizationService.GetResourceAsync("ActivityLog.AddNewTopic"), topic.Title ?? topic.SystemName), topic);
            }
            await _localizationService.AddOrUpdateLocaleResourceAsync(new Dictionary<string, string>
            {
                ["Plugins.Misc.CheckOrderStatus.Configuration"] = "Configuration",
                ["Plugins.Misc.CheckOrderStatus.Configuration.Title"] = "Check Order Status Settings",
                ["Plugins.Misc.CheckOrderStatus.Log"] = "Check Order Status Log",
                ["Plugins.Misc.CheckOrderStatus.Enabled"] = "Enabled",
                ["Plugins.Misc.CheckOrderStatus.Enabled.Hint"] = "Enable or disable plugin by toggle the check button.",                
                ["Plugins.Misc.CheckOrderStatus.CustomOrderNumber"] ="Order number",
                ["Plugins.Misc.CheckOrderStatus.CustomOrderNumber.Required"] ="Order number is required",
                ["Plugins.Misc.CheckOrderStatus.CustomerEmail"] = "Customer email",
                ["Plugins.Misc.CheckOrderStatus.CustomerEmail.Required"]="Customer email is required",
                ["Plugins.Misc.CheckOrderStatus.EmailMismatch"] = "Email mismatch",
                ["Plugins.Misc.CheckOrderStatus.ResponseMessage"] = "Response message",
                ["Plugins.Misc.CheckOrderStatus.CreatedDate"] = "Created date",
                ["Plugins.Misc.CheckOrderStatus.OrderId.Required"] = "Order number is required",
                ["Plugins.Misc.CheckOrderStatus.Email.Required"] = "Customer email is required",
                ["Plugins.Misc.CheckOrderStatus.CreatedFrom"] = "From",
                ["Plugins.Misc.CheckOrderStatus.CreatedTo"] = "To",
                ["Plugins.Misc.CheckOrderStatus.PageTitle"] = "Page title",
                ["Plugins.Misc.CheckOrderStatus.PageTitle.hint"] = "Check order status public page title",
                ["Plugins.Misc.CheckOrderStatus.MetaTitle"] = "Meta title",
                ["Plugins.Misc.CheckOrderStatus.MetaTitle.Hint"] = "Override the check order status page title.",
                ["Plugins.Misc.CheckOrderStatus.MetaDescription"] = "Meta description",
                ["Plugins.Misc.CheckOrderStatus.MetaDescription.Hint"] = "Meta description to be added to check order status page header",
                ["Plugins.Misc.CheckOrderStatus.MetaKeywords"] = "Meta keywords",
                ["Plugins.Misc.CheckOrderStatus.MetaKeywords.Hint"] = "Keywords to be added to check order status page header",
                ["Plugins.Misc.CheckOrderStatus.CustomerInstructions"] = "Enter your order information",
                ["Plugins.Misc.CheckOrderStatus.CustomerInstructions.Hint"] = "Instruct customer to fill out form on check order status public page",
                ["Plugins.Misc.CheckOrderStatus.CustomerNote"] = "Customer note",
                ["Plugins.Misc.CheckOrderStatus.CustomerNote.Hint"] = "Explanatory note on the check order status public page appears before the submit button",
                ["Plugins.Misc.CheckOrderStatus.DisplayCaptcha"] = "Display captcha",
                ["Plugins.Misc.CheckOrderStatus.DisplayCaptcha.Hint"] = "Display captcha on check order status plublic page. CAPTCHA must be enable for the store",
                ["Plugins.Misc.CheckOrderStatus.IncludeInFooterColumn1"] = "Include In Footer Column 1",
                ["Plugins.Misc.CheckOrderStatus.IncludeInFooterColumn1.Hint"] = "Include Check Order Status Link In Footer Column 1",
                ["Plugins.Misc.CheckOrderStatus.IncludeInFooterColumn2"] = "Include In Footer Column 2",
                ["Plugins.Misc.CheckOrderStatus.IncludeInFooterColumn2.Hint"] = "Include Check Order Status Link In Footer Column 2",
                ["Plugins.Misc.CheckOrderStatus.IncludeInFooterColumn3"] = "Include In Footer Column 3",
                ["Plugins.Misc.CheckOrderStatus.IncludeInFooterColumn3.Hint"] = "Include Check Order Status Link In Footer Column 3",
                ["Plugins.Misc.CheckOrderStatus.IncludeInTopMenu"] = "Include In Top Menu",
                ["Plugins.Misc.CheckOrderStatus.IncludeInTopMenu.Hint"] = "Include Check Order Status Link In Top Menu",
                ["Plugins.Misc.CheckOrderStatus.DisplayOrder"] = "Display order",
                ["Plugins.Misc.CheckOrderStatus.DisplayOrder.Hint"] = "Display order of check order status link on footer column",
                ["Plugins.Misc.CheckOrderStatus.EnableLogging"] = "Enable logging",
                ["Plugins.Misc.CheckOrderStatus.EnableLogging.Hint"] = "Collect information every time customers check their order status",
                ["Plugins.Misc.CheckOrderStatus.OrderId"] = "Order Id",
                ["Plugins.Misc.CheckOrderStatus.CustomerEmail"] = "Customer Email",
                ["Plugins.Misc.CheckOrderStatus.CreatedDate"] = "Created On",
                ["Plugins.Misc.CheckOrderStatus.CheckStatus"] = "Check Status",
                ["Plugins.Misc.CheckOrderStatus.Store"] = "Store"

            });
            await base.InstallAsync();

        }
        public override async Task UninstallAsync()
        {
            //settings
            await _settingService.DeleteSettingAsync<CheckOrderStatusSettings>();
            //locales
            await _localizationService.DeleteLocaleResourceAsync("Plugins.Misc.CheckOrderStatus");
            var checkOrderStatusTopic = await _topicService.GetTopicBySystemNameAsync("OrderStatusCheck");
            if(checkOrderStatusTopic != null)
                await _topicService.DeleteTopicAsync(checkOrderStatusTopic);
            var cosUrlRecord = await _urlRecordService.GetBySlugAsync("CheckOrderStatus");
            if (cosUrlRecord != null)
            {
                var urlRecords = new List<UrlRecord>
                {
                    cosUrlRecord
                };
                await _urlRecordService.DeleteUrlRecordsAsync(urlRecords);
            }   
            await base.UninstallAsync();
        }
    }
}
